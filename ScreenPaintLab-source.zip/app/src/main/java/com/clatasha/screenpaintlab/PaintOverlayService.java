package com.clatasha.screenpaintlab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public final class PaintOverlayService extends Service {
    public static final String ACTION_STOP = "com.clatasha.screenpaintlab.STOP_OVERLAY";
    private WindowManager wm;
    private DrawingView drawing;
    private LinearLayout toolbar;
    private WindowManager.LayoutParams drawingParams;
    private boolean paintMode = false;
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (toolbar == null) startOverlay();
        return START_NOT_STICKY;
    }
    private void startOverlay() {
        NotificationChannel channel = new NotificationChannel("paint_overlay", "Painting overlay", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        Notification notification = new Notification.Builder(this, "paint_overlay")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("Screen Paint Lab: drawing overlay")
                .setContentText("Floating toolbar available. Stop in the app.")
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(202, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(202, notification);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        drawing = new DrawingView();
        drawingParams = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        drawingParams.gravity = Gravity.TOP | Gravity.START;
        toolbar = new LinearLayout(this);
        toolbar.setPadding(dp(6), dp(5), dp(6), dp(5));
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xf0162636);
        bg.setCornerRadius(dp(15));
        toolbar.setBackground(bg);
        addButton("DRAW", v -> setPaintMode(true));
        addButton("TOUCH APP", v -> setPaintMode(false));
        addButton("SAVE PNG", v -> saveDrawing());
        addButton("CLEAR", v -> drawing.clear());
        addButton("×", v -> stopSelf());
        WindowManager.LayoutParams controls = new WindowManager.LayoutParams(-2, -2,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        controls.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        controls.y = dp(48);
        wm.addView(toolbar, controls);
        // Starts in TOUCH APP mode so normal interaction with the underlying app works.
        // When DRAW is pressed, the full-screen canvas becomes touchable and intercepts gestures.
        paintMode = false;
    }
    private void setPaintMode(boolean enabled) {
        if (enabled == paintMode) return;
        try {
            if (enabled) {
                wm.addView(drawing, drawingParams);
                // Re-add toolbar after canvas to keep controls above painting surface.
                wm.removeView(toolbar);
                WindowManager.LayoutParams controls = new WindowManager.LayoutParams(-2, -2,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                        PixelFormat.TRANSLUCENT);
                controls.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                controls.y = dp(48);
                wm.addView(toolbar, controls);
            } else {
                wm.removeView(drawing);
            }
            paintMode = enabled;
            Toast.makeText(this, enabled ? "Paint on screen. TOUCH APP to interact again." : "Touches now reach the app behind the toolbar.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.util.Log.e("ScreenPaintLab", "Overlay mode error", e);
        }
    }
    private void addButton(String label, View.OnClickListener action) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(10);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setMinimumWidth(0);
        button.setMinWidth(0);
        button.setPadding(dp(5), 0, dp(5), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42));
        toolbar.addView(button, lp);
        button.setOnClickListener(action);
    }
    private void saveDrawing() {
        if (drawing == null) return;
        if (drawing.paths.isEmpty()) {
            Toast.makeText(this, "Draw something first — this only saves strokes.", Toast.LENGTH_LONG).show();
            return;
        }
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        drawing.renderPaths(canvas);
        String when = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "Painting_" + when + ".png");
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenPaintLab");
        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) { Toast.makeText(this, "Could not create Gallery file", Toast.LENGTH_LONG).show(); return; }
        try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
            if (stream == null || !bmp.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw new IllegalStateException("PNG write failed");
            cv.clear(); cv.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, cv, null, null);
            Toast.makeText(this, "Drawing saved to Pictures/ScreenPaintLab", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally { bmp.recycle(); }
    }
    private int dp(int number) { return Math.round(number * getResources().getDisplayMetrics().density); }
    @Override public void onDestroy() {
        if (wm != null) {
            try { if (toolbar != null) wm.removeView(toolbar); } catch (Exception ignored) {}
            try { if (drawing != null && paintMode) wm.removeView(drawing); } catch (Exception ignored) {}
        }
        toolbar = null; drawing = null;
        super.onDestroy();
    }
    private final class DrawingView extends View {
        final ArrayList<Path> paths = new ArrayList<>();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Path current;
        DrawingView() {
            super(PaintOverlayService.this);
            paint.setColor(0xff3df0dd);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(5));
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
        }
        @Override protected void onDraw(Canvas canvas) { renderPaths(canvas); }
        void renderPaths(Canvas canvas) { for (Path p : paths) canvas.drawPath(p, paint); }
        void clear() { paths.clear(); current = null; invalidate(); }
        @Override public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    current = new Path();
                    current.moveTo(ev.getX(), ev.getY());
                    paths.add(current);
                    invalidate(); return true;
                case MotionEvent.ACTION_MOVE:
                    if (current != null) current.lineTo(ev.getX(), ev.getY());
                    invalidate(); return true;
                case MotionEvent.ACTION_UP:
                    if (current != null) current.lineTo(ev.getX(), ev.getY());
                    current = null; invalidate(); return true;
                case MotionEvent.ACTION_CANCEL:
                    current = null; return true;
                default: return true;
            }
        }
    }
}
