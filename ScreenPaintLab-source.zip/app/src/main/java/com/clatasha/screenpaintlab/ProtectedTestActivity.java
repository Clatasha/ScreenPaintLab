package com.clatasha.screenpaintlab;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class ProtectedTestActivity extends Activity {
    private boolean secure = true;
    private TextView stateLabel;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xff101420);
        root.addView(new PatternView());
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(18), dp(14), dp(18), dp(12));
        controls.setBackgroundColor(0xdd101420);
        stateLabel = new TextView(this);
        stateLabel.setTextColor(Color.WHITE);
        stateLabel.setTextSize(19);
        controls.addView(stateLabel);
        Button toggle = new Button(this);
        toggle.setText("Toggle protection ON / OFF");
        toggle.setAllCaps(false);
        controls.addView(toggle);
        toggle.setOnClickListener(v -> {
            secure = !secure;
            if (secure) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            updateStatus();
        });
        Button close = new Button(this);
        close.setText("Back to lab");
        close.setAllCaps(false);
        controls.addView(close);
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams controlParams = new FrameLayout.LayoutParams(-1, -2);
        controlParams.gravity = android.view.Gravity.BOTTOM;
        root.addView(controls, controlParams);
        setContentView(root);
        updateStatus();
    }
    private void updateStatus() {
        stateLabel.setText(secure ? "PROTECTED / FLAG_SECURE ON" : "UNPROTECTED / FLAG_SECURE OFF");
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private final class PatternView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        PatternView() { super(ProtectedTestActivity.this); }
        @Override protected void onDraw(Canvas canvas) {
            int w = getWidth(), h = getHeight();
            paint.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xff2752d7, 0xffef4788, 0xfff7bd43}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            paint.setColor(0xee091625);
            float size = Math.min(w, h) / 7f;
            for (int i = 0; i < 5; i++) {
                paint.setColor(i % 2 == 0 ? 0xff54f0db : 0xffffda52);
                canvas.drawCircle(w * (0.16f + i * 0.17f), h * (0.34f + (i % 2) * 0.13f), size * (0.42f + i * 0.06f), paint);
            }
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(w / 15f);
            paint.setFakeBoldText(true);
            canvas.drawText("CAPTURE TEST", w / 2f, h * 0.16f, paint);
            paint.setTextSize(w / 25f);
            paint.setFakeBoldText(false);
            canvas.drawText("THESE COLORS SHOULD DISAPPEAR", w / 2f, h * 0.22f, paint);
            canvas.drawText("FROM PROTECTED RECORDINGS", w / 2f, h * 0.26f, paint);
        }
    }
}
