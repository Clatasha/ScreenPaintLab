package com.clatasha.screenpaintlab;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int REQUEST_PROJECTION = 401;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        makeUi();
    }

    private void makeUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(13, 17, 27));
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(dp(22), dp(36), dp(22), dp(28));
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);
        TextView title = text("Screen Paint Lab", 29, Color.WHITE, true);
        layout.addView(title);
        TextView subtitle = text("CLATASHA  •  ANDROID EXPERIMENT 01", 11, Color.rgb(94, 221, 217), true);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        layout.addView(subtitle);
        textInto(layout, "Investigate recording and drawing on protected screens. No root required. No protected-content bypass is provided.", 14, 0xffc0c9d9, false);

        status = text("", 13, Color.WHITE, false);
        status.setPadding(dp(15), dp(13), dp(15), dp(13));
        status.setBackground(background(0xff202b39, 12));
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(21);
        layout.addView(status, statusParams);
        refreshStatus();

        section(layout, "01 / RECORDING PROBE", "Ask Android to capture the display at approximately 2-second intervals. Saved frames show what the API actually receives.");
        button(layout, "Start screen probe", () -> {
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_PROJECTION);
        }, true);
        button(layout, "Stop screen probe", () -> {
            Intent stop = new Intent(this, ScreenProbeService.class);
            stop.setAction(ScreenProbeService.ACTION_STOP);
            startService(stop);
            toast("Stopping recording probe");
        }, false);

        section(layout, "02 / PROTECTED TEST", "Compare the same colorful test image with Android FLAG_SECURE on and off. You can flip it while the probe runs.");
        button(layout, "Open protected sample", () -> startActivity(new Intent(this, ProtectedTestActivity.class)), false);

        section(layout, "03 / TRANSPARENT PAINT", "Open a small floating toolbar, then choose DRAW to trace manually over another app. SAVE PNG saves your strokes, not the photograph behind them.");
        button(layout, "Enable / start paint overlay", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent settings = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                toast("Allow 'Appear on top', then return and tap this button again");
            } else {
                startForegroundService(new Intent(this, PaintOverlayService.class));
                toast("Floating toolbar enabled: use DRAW / TOUCH APP");
            }
        }, true);
        button(layout, "Close paint overlay", () -> {
            Intent stop = new Intent(this, PaintOverlayService.class);
            stop.setAction(PaintOverlayService.ACTION_STOP);
            startService(stop);
        }, false);

        section(layout, "04 / REVIEW RESULTS", "Your screenshots and transparent drawings are in Pictures/ScreenPaintLab. The probe stores up to 40 PNG frames per session.");
        button(layout, "Refresh saved-frame count", this::refreshStatus, false);
        button(layout, "Open device pictures", () -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_DEFAULT);
            try { startActivity(i); }
            catch (Exception e) { toast("Open Gallery or My Files → Pictures → ScreenPaintLab"); }
        }, false);
        textInto(layout, "NOTE: View Once images can disappear permanently after being opened. Test with the built-in protected sample before trying a one-time photo.", 13, 0xffffc78f, false);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshStatus();
    }

    private void refreshStatus() {
        if (status == null) return;
        int count = getSharedPreferences("probe", MODE_PRIVATE).getInt("saved_count", 0);
        status.setText("Saved diagnostic frames: " + count + "\nStorage: Pictures / ScreenPaintLab");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PROJECTION) return;
        if (resultCode != RESULT_OK || data == null) {
            toast("Android screen-capture permission was not granted");
            return;
        }
        Intent i = new Intent(this, ScreenProbeService.class);
        i.setAction(ScreenProbeService.ACTION_START);
        i.putExtra(ScreenProbeService.EXTRA_RESULT_CODE, resultCode);
        i.putExtra(ScreenProbeService.EXTRA_RESULT_DATA, data);
        startForegroundService(i);
        toast("Probe started. Open the sample screen, then return to stop.");
    }

    private void section(LinearLayout layout, String header, String info) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(29);
        TextView t = text(header, 14, 0xff5edbd7, true);
        layout.addView(t, lp);
        TextView d = text(info, 14, 0xffa8b8ca, false);
        d.setPadding(0, dp(7), 0, dp(10));
        layout.addView(d);
    }
    private void button(LinearLayout layout, String label, Runnable action, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(primary ? 0xff09202b : Color.WHITE);
        b.setBackground(background(primary ? 0xff58ddd5 : 0xff273346, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(51));
        lp.bottomMargin = dp(8);
        layout.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }
    private void textInto(LinearLayout layout, String s, int sp, int color, boolean bold) {
        TextView t = text(s, sp, color, bold);
        t.setPadding(0, dp(9), 0, dp(4));
        layout.addView(t);
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable background(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
