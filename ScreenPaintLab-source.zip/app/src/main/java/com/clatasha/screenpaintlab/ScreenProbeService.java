package com.clatasha.screenpaintlab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ScreenProbeService extends Service {
    public static final String ACTION_START = "com.clatasha.screenpaintlab.START_PROBE";
    public static final String ACTION_STOP = "com.clatasha.screenpaintlab.STOP_PROBE";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "probe_status";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private long lastSaveTime = 0;
    private int sessionCount = 0;
    private boolean stopping = false;
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() { stopSelf(); }
    };
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!ACTION_START.equals(intent.getAction()) || projection != null) return START_NOT_STICKY;
        createChannel();
        Notification notice = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Screen Paint Lab: screen probe active")
                .setContentText("Capturing diagnostic frames (max 40). Open app to stop.")
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(201, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(201, notice);
        try {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent token;
            if (Build.VERSION.SDK_INT >= 33) {
                token = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            } else {
                token = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }
            if (token == null || resultCode != android.app.Activity.RESULT_OK) throw new IllegalStateException("Missing capture grant");
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(resultCode, token);
            thread = new HandlerThread("Capture frames");
            thread.start();
            Handler handler = new Handler(thread.getLooper());
            projection.registerCallback(projectionCallback, handler);
            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels, height = metrics.heightPixels;
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(r -> {
                Image image = null;
                try {
                    image = r.acquireLatestImage();
                    if (image == null || stopping) return;
                    long now = SystemClock.elapsedRealtime();
                    if (now - lastSaveTime < 2000 || sessionCount >= 40) return;
                    lastSaveTime = now;
                    Bitmap bmp = extractBitmap(image);
                    if (bmp != null) {
                        boolean saved = saveBitmap(bmp, "Probe");
                        bmp.recycle();
                        if (saved) {
                            sessionCount++;
                            getSharedPreferences("probe", MODE_PRIVATE).edit()
                                    .putInt("saved_count", getSharedPreferences("probe", MODE_PRIVATE).getInt("saved_count", 0) + 1).apply();
                        }
                    }
                    if (sessionCount >= 40) stopSelf();
                } catch (Exception ex) {
                    android.util.Log.e("ScreenPaintLab", "Frame capture failed", ex);
                } finally {
                    if (image != null) image.close();
                }
            }, handler);
            display = projection.createVirtualDisplay("Screen Paint Lab", width, height,
                    metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);
        } catch (Exception ex) {
            android.util.Log.e("ScreenPaintLab", "Could not start probe", ex);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Bitmap extractBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth(), height = image.getHeight();
        int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
        int paddedWidth = width + (rowStride - pixelStride * width) / pixelStride;
        Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        padded.copyPixelsFromBuffer(buffer);
        Bitmap crop = Bitmap.createBitmap(padded, 0, 0, width, height);
        if (crop != padded) padded.recycle();
        return crop;
    }

    private boolean saveBitmap(Bitmap bitmap, String prefix) {
        String when = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, prefix + "_" + when + ".png");
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenPaintLab");
        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) return false;
        try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
            if (stream == null || !bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw new IllegalStateException("Write failed");
            cv.clear();
            cv.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, cv, null, null);
            return true;
        } catch (Exception ex) {
            getContentResolver().delete(uri, null, null);
            return false;
        }
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Screen probe", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }
    @Override public void onDestroy() {
        stopping = true;
        if (reader != null) { reader.setOnImageAvailableListener(null, null); reader.close(); reader = null; }
        if (display != null) { display.release(); display = null; }
        if (projection != null) {
            projection.unregisterCallback(projectionCallback);
            projection.stop();
            projection = null;
        }
        if (thread != null) { thread.quitSafely(); thread = null; }
        super.onDestroy();
    }
}
