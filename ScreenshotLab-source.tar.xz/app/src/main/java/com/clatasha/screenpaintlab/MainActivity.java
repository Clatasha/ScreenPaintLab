package com.clatasha.screenpaintlab;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 401;
    private static final int BG = 0xff0a111d, PANEL = 0xff152231;
    private static final int ACCENT = 0xff55ebd4, TEXT = 0xfff3f8fc, MUTED = 0xff97aabb;
    private String pendingMode = CaptureService.MODE_SCREENSHOT;
    private TextView savedLabel, currentStatus;
    private TextView quality720, quality1080;

    @Override public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 40);
        }
        drawHome();
    }

    private void drawHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(28), dp(22), dp(30));
        scroll.addView(body);

        LinearLayout brand = horizontal();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1, dp(65));
        brandLp.bottomMargin = dp(30);
        body.addView(brand, brandLp);
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.clatasha.screenpaintlab.R.drawable.ic_shot_foreground);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setBackground(round(0xff102535, 18, 0xff2b7776));
        brand.addView(logo, new LinearLayout.LayoutParams(dp(62), dp(62)));
        LinearLayout words = vertical();
        words.setPadding(dp(14), 0, 0, 0);
        brand.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        words.addView(text("Screenshot Lab", 23, TEXT, true));
        TextView cred = text("CLATASHA  /  CREATIVE TOOLS", 10, ACCENT, true);
        cred.setLetterSpacing(.13f);
        cred.setPadding(0, dp(5), 0, 0);
        words.addView(cred);

        TextView eyebrow = text("YOUR SCREEN. YOUR STORY.", 11, ACCENT, true);
        eyebrow.setLetterSpacing(.14f);
        body.addView(eyebrow);
        TextView hero = text("Capture anything.\nMake it yours.", 32, TEXT, true);
        hero.setLineSpacing(dp(1), 1.02f);
        hero.setPadding(0, dp(9), 0, dp(10));
        body.addView(hero);
        TextView sub = text("Beautiful screenshots, screen video and freehand annotations — in one simple workspace.", 14, MUTED, false);
        sub.setLineSpacing(dp(3), 1f);
        body.addView(sub);

        LinearLayout info = horizontal();
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(16), dp(14), dp(16), dp(14));
        info.setBackground(round(0xff142734, 16, 0xff28504d));
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(-1, -2);
        infoParams.topMargin = dp(26);
        infoParams.bottomMargin = dp(14);
        body.addView(info, infoParams);
        TextView icon = text("●", 16, ACCENT, true);
        info.addView(icon);
        currentStatus = text("Ready when you are", 13, TEXT, true);
        currentStatus.setPadding(dp(9), 0, 0, 0);
        info.addView(currentStatus);

        feature(body, "01", "Screenshot", "Capture a clean, high-resolution image of your screen.", "TAKE SCREENSHOT", true,
                () -> askCapture(CaptureService.MODE_SCREENSHOT));
        feature(body, "02", "Screen recorder", "Record smooth MP4 video. Stop anytime from the notification.", "START RECORDING", false,
                () -> askCapture(CaptureService.MODE_VIDEO));
        feature(body, "03", "Draw on screen", "Mark up any normal screen and save your artwork with its background.", "START MARKUP", false,
                () -> startMarkup());

        LinearLayout prefs = vertical();
        prefs.setPadding(dp(18), dp(17), dp(18), dp(17));
        prefs.setBackground(round(PANEL, 18, 0xff263a4c));
        LinearLayout.LayoutParams prefLp = new LinearLayout.LayoutParams(-1, -2);
        prefLp.topMargin = dp(18);
        body.addView(prefs, prefLp);
        prefs.addView(text("Recording quality", 15, TEXT, true));
        TextView description = text("MP4 video • 30 FPS • no microphone audio", 12, MUTED, false);
        description.setPadding(0, dp(5), 0, dp(13));
        prefs.addView(description);
        LinearLayout segmented = horizontal();
        prefs.addView(segmented);
        quality720 = chip(segmented, "720p  /  smaller file", () -> setQuality(720));
        quality1080 = chip(segmented, "1080p  /  sharper", () -> setQuality(1080));
        updateQuality();

        LinearLayout library = horizontal();
        library.setGravity(Gravity.CENTER_VERTICAL);
        library.setPadding(dp(17), dp(16), dp(17), dp(16));
        library.setBackground(round(0xff101b29, 16, 0xff253447));
        LinearLayout.LayoutParams libraryLp = new LinearLayout.LayoutParams(-1, -2);
        libraryLp.topMargin = dp(18);
        body.addView(library, libraryLp);
        LinearLayout labelBox = vertical();
        library.addView(labelBox, new LinearLayout.LayoutParams(0, -2, 1));
        labelBox.addView(text("Your captures", 16, TEXT, true));
        savedLabel = text("Pictures & Movies / ScreenshotLab", 12, MUTED, false);
        savedLabel.setPadding(0, dp(5), 0, 0);
        labelBox.addView(savedLabel);
        TextView open = text("OPEN  ↗", 12, ACCENT, true);
        library.addView(open);
        library.setOnClickListener(v -> openGallery());

        TextView foot = text("PRIVACY BY DESIGN  •  Only you control recording. Protected screens remain protected.", 11, 0xff637c90, false);
        foot.setLineSpacing(dp(2), 1f);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(28);
        body.addView(foot, footLp);
        setContentView(scroll);
        updateHome();
    }

    private void feature(LinearLayout body, String number, String title, String detail,
                         String buttonTitle, boolean emphasized, Runnable command) {
        LinearLayout card = vertical();
        card.setPadding(dp(18), dp(16), dp(18), dp(17));
        card.setBackground(round(emphasized ? 0xff18343b : PANEL, 19, emphasized ? 0xff337b76 : 0xff273c4b));
        LinearLayout.LayoutParams margin = new LinearLayout.LayoutParams(-1, -2);
        margin.bottomMargin = dp(11);
        body.addView(card, margin);
        LinearLayout first = horizontal();
        first.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(first);
        TextView idx = text(number, 14, ACCENT, true);
        idx.setPadding(0, 0, dp(13), 0);
        first.addView(idx);
        first.addView(text(title, 19, TEXT, true));
        TextView desc = text(detail, 13, MUTED, false);
        desc.setPadding(0, dp(8), 0, dp(14));
        card.addView(desc);
        TextView action = text(buttonTitle + "    →", 12, emphasized ? BG : ACCENT, true);
        action.setGravity(Gravity.CENTER);
        action.setLetterSpacing(.07f);
        action.setBackground(round(emphasized ? ACCENT : 0xff203b47, 12, emphasized ? ACCENT : 0xff346473));
        card.addView(action, new LinearLayout.LayoutParams(-1, dp(42)));
        action.setOnClickListener(v -> command.run());
        card.setOnClickListener(v -> command.run());
    }

    private TextView chip(LinearLayout holder, String label, Runnable task) {
        TextView chip = text(label, 12, TEXT, true);
        chip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.rightMargin = dp(8);
        holder.addView(chip, lp);
        chip.setOnClickListener(v -> task.run());
        return chip;
    }

    private void setQuality(int value) {
        getSharedPreferences("settings", MODE_PRIVATE).edit().putInt("quality", value).apply();
        updateQuality();
    }
    private void updateQuality() {
        int selected = getSharedPreferences("settings", MODE_PRIVATE).getInt("quality", 1080);
        if (quality720 != null) quality720.setBackground(round(selected == 720 ? 0xff286a65 : 0xff243345, 10, selected == 720 ? ACCENT : 0xff35485a));
        if (quality1080 != null) quality1080.setBackground(round(selected == 1080 ? 0xff286a65 : 0xff243345, 10, selected == 1080 ? ACCENT : 0xff35485a));
    }
    private void updateHome() {
        if (currentStatus != null) {
            currentStatus.setText(CaptureService.isCapturing() ? "Screen capture is active" : "Ready when you are");
        }
        if (savedLabel != null) {
            int shots = getSharedPreferences("counts", MODE_PRIVATE).getInt("images", 0);
            int videos = getSharedPreferences("counts", MODE_PRIVATE).getInt("videos", 0);
            savedLabel.setText(shots + " screenshots  •  " + videos + " videos");
        }
    }

    private void startMarkup() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable 'Appear on top', then tap Start markup again.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        askCapture(CaptureService.MODE_MARKUP);
    }

    private void askCapture(String mode) {
        if (CaptureService.isCapturing()) {
            toast("Finish the current capture using its notification first.");
            return;
        }
        pendingMode = mode;
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQUEST_CAPTURE) return;
        if (result != RESULT_OK || data == null) { toast("Screen sharing was cancelled."); return; }
        Intent service = new Intent(this, CaptureService.class);
        service.setAction(CaptureService.ACTION_START);
        service.putExtra(CaptureService.EXTRA_MODE, pendingMode);
        service.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
        service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        startForegroundService(service);
        moveTaskToBack(true);
    }

    private void openGallery() {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_DEFAULT);
        try { startActivity(i); }
        catch (Exception ex) { toast("Open Samsung Gallery or My Files → Pictures / ScreenshotLab"); }
    }
    @Override protected void onResume() { super.onResume(); updateHome(); }
    private TextView text(String string, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(string);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private GradientDrawable round(int fill, float radius, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), border);
        return d;
    }
    private int dp(float n) { return Math.round(getResources().getDisplayMetrics().density * n); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
