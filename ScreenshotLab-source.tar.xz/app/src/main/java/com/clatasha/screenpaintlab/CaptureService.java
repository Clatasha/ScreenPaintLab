package com.clatasha.screenpaintlab;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** User-consented screenshots, screen video, and screen + annotation compositing. */
public final class CaptureService extends Service {
    public static final String ACTION_START = "com.clatasha.screenpaintlab.CAPTURE_START";
    public static final String ACTION_STOP = "com.clatasha.screenpaintlab.CAPTURE_STOP";
    public static final String ACTION_SAVE_MARKUP = "com.clatasha.screenpaintlab.SAVE_MARKUP";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_SCREENSHOT = "screenshot";
    public static final String MODE_VIDEO = "video";
    public static final String MODE_MARKUP = "markup";
    private static final String CHANNEL = "screenshotlab_capture";
    private static final String TAG = "ScreenshotLab";
    private static volatile boolean capturing = false;

    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private MediaRecorder recorder;
    private ParcelFileDescriptor videoFile;
    private Uri videoUri;
    private String mode;
    private boolean finished = false;
    private boolean videoStarted = false;
    private volatile boolean imagePending = false;
    private volatile long earliestImageMillis;
    private volatile boolean annotationShot = false;
    private int displayWidth, displayHeight;
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            main.post(() -> finishCapture("Android ended screen sharing."));
        }
    };

    public static boolean isCapturing() { return capturing; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { finishCapture(null); return START_NOT_STICKY; }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) { finishCapture(null); return START_NOT_STICKY; }
        if (ACTION_SAVE_MARKUP.equals(action)) {
            if (MODE_MARKUP.equals(mode) && projection != null && !imagePending) beginMarkupSave();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || capturing) return START_NOT_STICKY;
        mode = intent.getStringExtra(EXTRA_MODE);
        if (!MODE_SCREENSHOT.equals(mode) && !MODE_VIDEO.equals(mode) && !MODE_MARKUP.equals(mode)) {
            stopSelf(); return START_NOT_STICKY;
        }
        capturing = true;
        createChannel();
        Notification notice = makeNotification();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(301, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(301, notice);
        try {
            Intent consent;
            if (Build.VERSION.SDK_INT >= 33) consent = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            else consent = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            int consentCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            if (consent == null || consentCode != Activity.RESULT_OK) throw new IllegalStateException("No permission granted");
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(consentCode, consent);
            if (projection == null) throw new IllegalStateException("Unable to open screen projection");
            projection.registerCallback(projectionCallback, main);
            DisplayMetrics metrics = new DisplayMetrics();
            ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);
            displayWidth = metrics.widthPixels;
            displayHeight = metrics.heightPixels;
            if (MODE_VIDEO.equals(mode)) startVideo(metrics);
            else startImageCapture(metrics);
        } catch (Exception error) {
            Log.e(TAG, "Could not begin capture", error);
            notifyUser("Could not start capture: " + error.getClass().getSimpleName());
            finishCapture(null);
        }
        return START_NOT_STICKY;
    }

    private void startImageCapture(DisplayMetrics metrics) {
        imageThread = new HandlerThread("ScreenshotLab pixels");
        imageThread.start();
        imageHandler = new Handler(imageThread.getLooper());
        imageReader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image frame = null;
            try {
                frame = reader.acquireLatestImage();
                if (frame == null || !imagePending || finished) return;
                if (SystemClock.elapsedRealtime() < earliestImageMillis) return;
                imagePending = false;
                Bitmap captured = extract(frame);
                if (captured == null) throw new IllegalStateException("No screen pixels returned");
                boolean withMarkup = annotationShot;
                if (withMarkup) {
                    Canvas canvas = new Canvas(captured);
                    PaintOverlayService overlay = PaintOverlayService.active();
                    if (overlay != null) overlay.renderOn(canvas);
                }
                boolean saved = saveImage(captured, withMarkup ? "Markup" : "Screenshot");
                captured.recycle();
                main.post(() -> {
                    if (withMarkup) {
                        PaintOverlayService overlay = PaintOverlayService.active();
                        if (overlay != null) overlay.restoreAfterCapture();
                        notifyUser(saved ? "Screenshot + drawing saved to Gallery." : "Could not save annotated image.");
                    } else {
                        notifyUser(saved ? "Screenshot saved to Gallery." : "Could not save screenshot.");
                        finishCapture(null);
                    }
                });
            } catch (Exception ex) {
                Log.e(TAG, "Screenshot problem", ex);
                imagePending = false;
                main.post(() -> {
                    PaintOverlayService overlay = PaintOverlayService.active();
                    if (overlay != null) overlay.restoreAfterCapture();
                    notifyUser("Capture failed. Try again.");
                    if (!MODE_MARKUP.equals(mode)) finishCapture(null);
                });
            } finally { if (frame != null) frame.close(); }
        }, imageHandler);
        virtualDisplay = projection.createVirtualDisplay("ScreenshotLab screenshots", displayWidth, displayHeight,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, imageHandler);
        if (MODE_SCREENSHOT.equals(mode)) {
            // Leave Screenshot Lab and the permission dialog before taking the screenshot.
            earliestImageMillis = SystemClock.elapsedRealtime() + 1200;
            imagePending = true;
            main.postDelayed(() -> {
                if (imagePending && !finished) {
                    imagePending = false;
                    notifyUser("No screenshot frame received. Try again.");
                    finishCapture(null);
                }
            }, 6000);
        } else {
            main.postDelayed(() -> {
                if (finished) return;
                startService(new Intent(this, PaintOverlayService.class));
                notifyUser("Markup active. DRAW to sketch, SAVE for screen + drawing.");
            }, 450);
        }
    }

    private void beginMarkupSave() {
        PaintOverlayService overlay = PaintOverlayService.active();
        if (overlay == null) { notifyUser("Markup toolbar is not active."); return; }
        overlay.hideForCapture();
        annotationShot = true;
        earliestImageMillis = SystemClock.elapsedRealtime() + 480;
        imagePending = true;
        main.postDelayed(() -> {
            if (imagePending && !finished) {
                imagePending = false;
                PaintOverlayService current = PaintOverlayService.active();
                if (current != null) current.restoreAfterCapture();
                notifyUser("No screen frame received. Tap Save to retry.");
            }
        }, 5000);
    }

    @SuppressWarnings("deprecation")
    private void startVideo(DisplayMetrics metrics) throws Exception {
        int max = getSharedPreferences("settings", MODE_PRIVATE).getInt("quality", 1080);
        float ratio = Math.min(1f, max / (float)Math.min(displayWidth, displayHeight));
        // This is a portrait-friendly limit on the longer screen edge; preserves aspect ratio.
        int outputWidth = (Math.max(2, Math.round(displayWidth * ratio)) / 2) * 2;
        int outputHeight = (Math.max(2, Math.round(displayHeight * ratio)) / 2) * 2;
        // Keep video dimensions within a typical baseline H.264 decoder range.
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "Recording_" + stamp() + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ScreenshotLab");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IllegalStateException("Could not create a video file");
        videoFile = getContentResolver().openFileDescriptor(videoUri, "w");
        if (videoFile == null) throw new IllegalStateException("Could not open video file");
        recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoFrameRate(30);
        recorder.setVideoSize(outputWidth, outputHeight);
        recorder.setVideoEncodingBitRate(max == 720 ? 3500000 : 6500000);
        recorder.setOutputFile(videoFile.getFileDescriptor());
        recorder.prepare();
        virtualDisplay = projection.createVirtualDisplay("ScreenshotLab recorder", outputWidth,
                outputHeight, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder.getSurface(), null, main);
        recorder.start();
        videoStarted = true;
        notifyUser("Recording started. Pull down notifications to stop.");
    }

    private Bitmap extract(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth(), height = image.getHeight();
        int step = plane.getPixelStride(), row = plane.getRowStride();
        int paddedWidth = width + (row - step * width) / step;
        Bitmap bitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        bitmap.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height);
        if (cropped != bitmap) bitmap.recycle();
        return cropped;
    }

    private boolean saveImage(Bitmap bitmap, String name) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name + "_" + stamp() + ".png");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenshotLab");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) return false;
        try (OutputStream output = getContentResolver().openOutputStream(uri)) {
            if (output == null || !bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
                throw new IllegalStateException("Could not write image data");
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
            int old = getSharedPreferences("counts", MODE_PRIVATE).getInt("images", 0);
            getSharedPreferences("counts", MODE_PRIVATE).edit().putInt("images", old + 1).apply();
            return true;
        } catch (Exception ex) {
            Log.e(TAG, "Screenshot save failed", ex);
            getContentResolver().delete(uri, null, null);
            return false;
        }
    }

    private void finishCapture(String reason) {
        if (finished) return;
        finished = true;
        capturing = false;
        imagePending = false;
        PaintOverlayService overlay = PaintOverlayService.active();
        if (overlay != null) {
            overlay.restoreAfterCapture();
            stopService(new Intent(this, PaintOverlayService.class));
        }
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close(); imageReader = null;
        }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (recorder != null) {
            boolean saved = false;
            try {
                if (videoStarted) {
                    recorder.stop();
                    saved = true;
                }
            } catch (Exception ex) { Log.w(TAG, "Video too short or failed", ex); }
            try { recorder.reset(); recorder.release(); } catch (Exception ignored) { }
            recorder = null;
            videoStarted = false;
            if (videoFile != null) {
                try { videoFile.close(); } catch (Exception ignored) { }
                videoFile = null;
            }
            if (videoUri != null) {
                if (saved) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(videoUri, done, null, null);
                    int old = getSharedPreferences("counts", MODE_PRIVATE).getInt("videos", 0);
                    getSharedPreferences("counts", MODE_PRIVATE).edit().putInt("videos", old + 1).apply();
                    notifyUser("Video saved to Movies / ScreenshotLab.");
                } else {
                    getContentResolver().delete(videoUri, null, null);
                    notifyUser("Recording was too short or could not be saved.");
                }
                videoUri = null;
            }
        } else if (videoFile != null) {
            try { videoFile.close(); } catch (Exception ignored) { }
            videoFile = null;
            if (videoUri != null) { getContentResolver().delete(videoUri, null, null); videoUri = null; }
        }
        if (projection != null) {
            projection.unregisterCallback(projectionCallback);
            projection.stop();
            projection = null;
        }
        if (imageThread != null) { imageThread.quitSafely(); imageThread = null; }
        if (reason != null) notifyUser(reason);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Notification makeNotification() {
        Intent stop = new Intent(this, CaptureService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent command = PendingIntent.getService(this, 907, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String type = MODE_VIDEO.equals(mode) ? "Screen recording" : MODE_MARKUP.equals(mode) ? "Screen markup" : "Saving screenshot";
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Screenshot Lab • " + type)
                .setContentText(MODE_VIDEO.equals(mode) ? "Tap Stop when finished recording" : "Capture permission is active")
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(R.drawable.ic_notification, "Stop", command).build())
                .build();
    }
    private void createChannel() {
        NotificationChannel c = new NotificationChannel(CHANNEL, "Screen captures", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
    }
    private String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()); }
    private void notifyUser(String message) { main.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }
    @Override public void onDestroy() { finishCapture(null); super.onDestroy(); }
}
