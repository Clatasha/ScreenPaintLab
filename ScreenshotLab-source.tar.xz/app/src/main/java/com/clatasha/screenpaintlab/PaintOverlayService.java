package com.clatasha.screenpaintlab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

/** Floating annotation layer. A CaptureService screenshot supplies the underlying background. */
public final class PaintOverlayService extends Service {
    public static final String ACTION_STOP = "com.clatasha.screenpaintlab.STOP_MARKUP";
    private static PaintOverlayService activeService;
    private static final int[] COLORS = {0xff55ebd4, 0xffffd166, 0xffff647e, 0xffffffff, 0xff7ca8ff};
    private int colorIndex = 0;
    private WindowManager window;
    private DrawingView drawing;
    private LinearLayout toolbar;
    private WindowManager.LayoutParams canvasParams, toolbarParams;
    private boolean drawingAttached = false;
    private boolean paintMode = false;
    private boolean saving = false;
    private TextView paintButton, colorButton;

    public static PaintOverlayService active() { return activeService; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf(); return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this) || !CaptureService.isCapturing()) {
            stopSelf(); return START_NOT_STICKY;
        }
        if (toolbar == null) setUpOverlay();
        return START_NOT_STICKY;
    }

    private void setUpOverlay() {
        NotificationChannel channel = new NotificationChannel("markup_controls", "Floating markup toolbar", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        Notification note = new Notification.Builder(this, "markup_controls")
                .setContentTitle("Screenshot Lab • Markup")
                .setContentText("Drawing tools are active. Save to Gallery when ready.")
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(302, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(302, note);
        activeService = this;
        window = (WindowManager)getSystemService(WINDOW_SERVICE);
        drawing = new DrawingView();
        canvasParams = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        canvasParams.gravity = Gravity.TOP | Gravity.START;

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(7), dp(4), dp(7), dp(4));
        toolbar.setElevation(dp(10));
        toolbar.setBackground(shape(0xf31a2838, 19, 0xff3e5967));
        paintButton = tool("DRAW", v -> setPaintMode(!paintMode));
        tool("SAVE", v -> saveWithScreen());
        tool("UNDO", v -> drawing.undo());
        colorButton = tool("COLOR", v -> {
            colorIndex = (colorIndex + 1) % COLORS.length;
            drawing.setBrushColor(COLORS[colorIndex]);
            colorButton.setTextColor(COLORS[colorIndex]);
        });
        tool("CLEAR", v -> drawing.clear());
        tool("×", v -> close());
        colorButton.setTextColor(COLORS[colorIndex]);
        toolbarParams = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        toolbarParams.y = dp(38);
        window.addView(toolbar, toolbarParams);
        setPaintMode(true);
    }

    private TextView tool(String label, View.OnClickListener action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextSize(10);
        item.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        item.setTextColor(0xffe7f5fc);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(36));
        toolbar.addView(item, lp);
        item.setOnClickListener(action);
        return item;
    }

    private void setPaintMode(boolean enabled) {
        if (saving || drawing == null) return;
        paintMode = enabled;
        try {
            if (enabled && !drawingAttached) {
                window.addView(drawing, canvasParams);
                drawingAttached = true;
                // Keep the toolbar above the drawing touch surface.
                window.removeView(toolbar);
                window.addView(toolbar, toolbarParams);
            } else if (!enabled && drawingAttached) {
                window.removeView(drawing);
                drawingAttached = false;
            }
            paintButton.setText(enabled ? "TOUCH" : "DRAW");
            paintButton.setTextColor(enabled ? 0xff55ebd4 : 0xffe7f5fc);
        } catch (Exception ignored) { }
    }

    private void saveWithScreen() {
        if (saving) return;
        saving = true;
        Toast.makeText(this, "Saving screenshot with markup…", Toast.LENGTH_SHORT).show();
        Intent save = new Intent(this, CaptureService.class);
        save.setAction(CaptureService.ACTION_SAVE_MARKUP);
        startService(save);
    }

    /** Hides OUR drawing and controls before MediaProjection samples the background. */
    public void hideForCapture() {
        if (toolbar != null) toolbar.setVisibility(View.INVISIBLE);
        if (drawing != null && drawingAttached) drawing.setVisibility(View.INVISIBLE);
    }
    public void restoreAfterCapture() {
        saving = false;
        if (toolbar != null) toolbar.setVisibility(View.VISIBLE);
        if (drawing != null && drawingAttached) drawing.setVisibility(View.VISIBLE);
    }

    /** Paints saved strokes on actual screen pixels; no access to protected pixels. */
    public void renderOn(Canvas canvas) {
        if (drawing == null) return;
        int[] pos = new int[2];
        if (drawingAttached) drawing.getLocationOnScreen(pos);
        else { pos[0] = 0; pos[1] = 0; }
        canvas.save();
        canvas.translate(pos[0], pos[1]);
        drawing.paintStrokes(canvas);
        canvas.restore();
    }

    private void close() {
        stopService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP));
        stopSelf();
    }

    private GradientDrawable shape(int color, int corner, int border) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(corner));
        shape.setStroke(dp(1), border);
        return shape;
    }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override public void onDestroy() {
        if (window != null) {
            try { if (toolbar != null) window.removeView(toolbar); } catch (Exception ignored) { }
            try { if (drawing != null && drawingAttached) window.removeView(drawing); } catch (Exception ignored) { }
        }
        toolbar = null;
        drawing = null;
        if (activeService == this) activeService = null;
        super.onDestroy();
    }

    private static final class Stroke {
        final Path line = new Path();
        final int color;
        final float width;
        Stroke(int color, float width) { this.color = color; this.width = width; }
    }
    private final class DrawingView extends View {
        private final ArrayList<Stroke> strokes = new ArrayList<>();
        private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Stroke current;
        private int brushColor = COLORS[0];
        DrawingView() { super(PaintOverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void setBrushColor(int color) { brushColor = color; }
        @Override protected void onDraw(Canvas canvas) { paintStrokes(canvas); }
        synchronized void paintStrokes(Canvas canvas) {
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeCap(Paint.Cap.ROUND);
            pen.setStrokeJoin(Paint.Join.ROUND);
            for (Stroke stroke : strokes) {
                pen.setColor(stroke.color);
                pen.setStrokeWidth(stroke.width);
                canvas.drawPath(stroke.line, pen);
            }
        }
        synchronized void undo() {
            if (!strokes.isEmpty()) strokes.remove(strokes.size() - 1);
            invalidate();
        }
        synchronized void clear() { strokes.clear(); current = null; invalidate(); }
        @Override public synchronized boolean onTouchEvent(MotionEvent event) {
            if (saving) return true;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                current = new Stroke(brushColor, dp(5));
                current.line.moveTo(event.getX(), event.getY());
                strokes.add(current);
                invalidate(); return true;
            } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (current != null) current.line.lineTo(event.getX(), event.getY());
                invalidate(); return true;
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                if (current != null) current.line.lineTo(event.getX(), event.getY());
                current = null;
                invalidate(); return true;
            }
            return true;
        }
    }
}
